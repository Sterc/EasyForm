<?php

require_once dirname(__DIR__, 2) . '/vendor/autoload.php';

/**
 * Class EasyForm
 */
class EasyForm extends Sterc\EasyForm {}
