<?php

namespace Sterc\EasyForm\Plugins;

/**
 * Plugin that sends autoresponder email.
 */
class AutoResponder extends Email
{
}
